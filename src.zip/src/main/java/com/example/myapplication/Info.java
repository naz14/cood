package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.content.Intent;

public class Info extends AppCompatActivity {
    private TextView intakeText;
    public float bmiWanted;
    public int calories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info);

    }

    public void calculate(View view) {
        Intent mIntent = getIntent();
        bmiWanted = (float) mIntent.getIntExtra("BMI", 0);

        bmiWanted = bmiWanted / 10f + 18f;

        intakeText = (TextView) findViewById(R.id.intakeText);

        EditText text1 = (EditText) findViewById(R.id.height);
        float height = Float.parseFloat(text1.getText().toString());
        EditText text2 = (EditText) findViewById(R.id.weight);
        float currentWeight = Float.parseFloat(text2.getText().toString());
        EditText text3 = (EditText) findViewById(R.id.workoutTime);
        float workoutTime = Float.parseFloat(text3.getText().toString());
        EditText text4 = (EditText) findViewById(R.id.goalDays);
        float goalDays = Float.parseFloat(text4.getText().toString());

        float goalWeight = bmiWanted * ((height/100) * (height/100));

        calories = (int) ((7000 * ((currentWeight - goalWeight) / goalDays)) - ((11*currentWeight)/60)*workoutTime);
        if(calories>0)
            intakeText.setText("Lower calorie intake by: \n" + calories + " kcal/day");
        else
            intakeText.setText("You will loose too much weight");
    }
}
