package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;


public class Women extends AppCompatActivity {
    private TextView textView;
    private SeekBar seekBar;
    private ImageView imageView;
    public float progressFloat;
    public int progressInt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.women);

        textView = (TextView) findViewById(R.id.textView);
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        imageView = (ImageView) findViewById(R.id.imageView);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                 progressFloat = progress / 10f + 18f;
                textView.setText("BMI: " + progressFloat + "");
                progressFloat = (progressFloat - 18f);

                if(progressFloat>=0 && progressFloat<=2.4)
                    imageView.setImageResource(R.drawable.w1);
                if(progressFloat>2.4 && progressFloat<=4.8)
                    imageView.setImageResource(R.drawable.w2);
                if(progressFloat>4.8 && progressFloat<=7.2)
                    imageView.setImageResource(R.drawable.w3);
                if(progressFloat>7.2 && progressFloat<=9.6)
                    imageView.setImageResource(R.drawable.w4);
                if(progressFloat>9.6 && progressFloat<=12)
                    imageView.setImageResource(R.drawable.w5);


                progressInt = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public void goToInfo (View view) {
        Intent intent = new Intent(getApplicationContext(), Info.class);
        intent.putExtra("BMI", progressInt);
        startActivity(intent);
    }
}