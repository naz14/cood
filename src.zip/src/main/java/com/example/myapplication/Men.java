package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;

public class Men extends AppCompatActivity {
    private TextView textView;
    private SeekBar seekBar;
    private ImageView imageView;
    public float progressFloat;
    public int progressInt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.men);

        textView = (TextView) findViewById(R.id.textView);
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.m1);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressFloat = progress / 10f + 18f;
                textView.setText("BMI: " + progressFloat + "");
                progressFloat = (progressFloat - 18f);

                if (progressFloat >= 0 && progressFloat <= 2.4)
                    imageView.setImageResource(R.drawable.m1);
                if (progressFloat > 2.4 && progressFloat <= 4.8)
                    imageView.setImageResource(R.drawable.m2);
                if (progressFloat > 4.8 && progressFloat <= 7.2)
                    imageView.setImageResource(R.drawable.m3);
                if (progressFloat > 7.2 && progressFloat <= 9.6)
                    imageView.setImageResource(R.drawable.m4);
                if (progressFloat > 9.6 && progressFloat <= 12)
                    imageView.setImageResource(R.drawable.m5);

                progressInt = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public void goToInfo (View view) {
        Intent intent = new Intent(getApplicationContext(), Info.class);
        intent.putExtra("BMI", progressInt);
        startActivity(intent);
    }
}